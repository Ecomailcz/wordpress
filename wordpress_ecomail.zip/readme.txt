=== Ecomail ===
Contributors: ecomail
Tags: ecomail
Requires at least: 2.5.0
Tested up to: 4.7
Stable tag: 1.0.0

Tento plugin slouží k propojení Ecomailu s vaším obchodem běžícím na platformě Wordpress.

== Description ==
**Proč si vybrat Ecomail.cz ?**

* Zaručíme Vám vyšší doručitelnost
* Zaručíme Vám vyšší doručitelnost
* Nejlepší ceny na trhu - lepší nenajdete
* Rychlá a vstřícná podpora

**Co připravujeme k tomuto pluginu do dalších verzí?**

* Užší integraci s akcemi ve Vašem obchodě
* Rozesílání newsletterů přímo z Wordpress

Napište nám na support@ecomail.cz a my Vám plugin přizpůsobíme!

Email : support@ecomail.cz
Phone : +420 777 139 129

== Instalace ==

1. Nainstalujte plugin z webových stránek WordPress Plugin Directory and proveďte jeho aktivaci.
2. Pokud ještě nemáte účet Ecomail, navštivte http://www.ecomail.cz/ a proveďte jeho vytvoření.
3. Na webové stránce klientské zóny Ecomail zkopírujte údaje API klíč a appId a vložte je do formuláře nastavení pluginu. Tento formulář naleznete v administraci instalace Wordpress na stránce Přehled pluginů pod odkazem Nastavení, který se nachází na řádku s pluginem Ecomail.

== Otisky obrazovky ==

1. 
2. 

== Changelog ==

= 1.0.0 =
První vydání